This is my Linux port of Ultravnc repeater source code. 

Compile with command: Make
You should now have a repeater file, start it with command ./repeater [inifilepathandname]

Various settings can be changed via ini file uvncrepeater.ini (read comments in file). 

If you have any questions, suggestions, bugfixes etc, contact me via email:jtkorhonen@gmail.com

Regards,

Jari Korhonen


